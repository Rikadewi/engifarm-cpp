#ifndef __RENDERABLES_H__
#define __RENDERABLES_H__

class Renderables {

    //Method untuk merender suatu objek
    virtual void render()=0; 

};
#endif