// livingthings.h
#ifndef __LIVINGTHINGS_H__
#define __LIVINGTHINGS_H__

class LivingThings : public Renderables {
    public:
        virtual void Move();
};

#endif 
